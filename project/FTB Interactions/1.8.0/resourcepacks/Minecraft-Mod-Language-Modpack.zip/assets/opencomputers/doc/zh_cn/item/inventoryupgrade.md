# Inventory Upgrade

![Where does it keep all this stuff...](oredict:oc:inventoryUpgrade)

物品栏升级使得[机器人](../block/robot.md) 和 [无人机](drone.md)拥有了物品栏. 每个升级为 [机器人](../block/robot.md) 提供16个槽位, 最大扩展到64; 为[无人机](drone.md) 提供4个槽位, 最大扩展到8.

如果不安装这个东西，那么他们就无法捡起或者丢掉物品
