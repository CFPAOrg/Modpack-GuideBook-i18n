#电池升级

![Made of Metal.](oredict:oc:batteryUpgrade1)

三星电子，超长待机！由真实大帝代言。 用于[机器人](../block/robot.md) ， [平板](tablet.md),让他们可以在野外坚持更久，等级越高存的越多。
