# 电路板

![Needs more gold.](oredict:oc:materialCircuitBoard)

从粗电路板合出来的东西 [raw circuit boards](rawCircuitBoard.md) 用于制作 [印刷电路板](printedCircuitBoard.md).
