# Interweb

![A website is a place where there's cobweb.](oredict:oc:materialInterweb)

用于长距离通信. 常用于 [因特网卡](internetCard.md) 和 [链接卡](linkedCard.md).
