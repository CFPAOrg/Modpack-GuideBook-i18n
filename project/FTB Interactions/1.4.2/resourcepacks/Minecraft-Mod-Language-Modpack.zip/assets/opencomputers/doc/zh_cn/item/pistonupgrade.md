# Piston Upgrade

![Push it.](oredict:oc:pistonUpgrade)

活塞升级让设备的行为变得像原版活塞那样. 安装后, 一个叫`push()`的函数可用. 调用时设备将会向面对的方向推出去. [机器人](../block/robot.md) 和 [单片机](../block/microcontroller.md)是方块的前方这个面; 对于[平板](tablet.md)是玩家的面对方向. 

推方块的行为遵循原版活塞.
