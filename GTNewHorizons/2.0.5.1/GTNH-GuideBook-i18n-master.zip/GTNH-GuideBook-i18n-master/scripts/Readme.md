# Guide for GTNH.js
1.Enter the mainpage of [JSZip](https://stuk.github.io/jszip/).<br />
2.Press F12 to open the console.<br />
3.Copy the content of GTNH.js to the console and press Enter.<br />
4.Type `parse("The version you want to work on.", true, true)` to get `en_US.lang` and the json file to replace the original one, or input `parse(true, false)` to get `result.lang`(An empty file which only contains "xxx.xxx.xxx=", waiting for translation).<br />

<br /><br />
## About Update
1.Enter the mainpage of [JSZip](https://stuk.github.io/jszip/).<br />
2.Press F12 to open the console.<br />
3.Copy the content of GTNH.js to the console and press Enter.<br />
4.Type `update("old_version", "new_version")` to get the comparing report, which can help you reduce your work.<br />

<br /><br />
## Updates
2017.7.30 Published 1.1.0 Added version so that you can choose the right version of the modpack.
2017.6.8 1.0.0 Published.