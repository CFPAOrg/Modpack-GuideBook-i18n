# GTNH.js 使用指南
1.进入[JSZip](https://stuk.github.io/jszip/)的首页<br />
2.F12打开控制台<br />
3.将GTNH.js的内容粘贴进控制台内<br />
4.输入`parse("你所需要的版本", true)`获得`en_US.lang`和覆盖用文件，或输入`parse(true, false)`获得`result.lang`(白版用于汉化的文件)<br />

<br /><br />
## 升级相关
1.进入[JSZip](https://stuk.github.io/jszip/)的首页<br />
2.F12打开控制台<br />
3.将GTNH.js的内容粘贴进控制台内<br />
4.输入`update("旧版本", "新版本")`获得比对信息<br />

<br /><br />
## 更新日志
2017.7.30 更新1.1.0 更新版本机制，补全更新功能中……
2017.6.8 发布1.0.0，勉强能用了……